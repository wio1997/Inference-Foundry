"""Client-only AISBench tokenizer bridge; target exactly the deployed model path."""
import os
from functools import lru_cache
from transformers import AutoTokenizer
_original=AutoTokenizer.from_pretrained.__func__
_target='/models/DeepSeek-V4.1-Flash-1017-w8a8'
@lru_cache(maxsize=1)
def deployed_tokenizer():
 from vllm.tokenizers import get_tokenizer
 return get_tokenizer(_target,tokenizer_mode='deepseek_v41')
@classmethod
def _from_pretrained(cls,pretrained_model_name_or_path,*args,**kwargs):
 if os.path.realpath(os.fspath(pretrained_model_name_or_path))==_target:return deployed_tokenizer()
 return _original(cls,pretrained_model_name_or_path,*args,**kwargs)
AutoTokenizer.from_pretrained=_from_pretrained
