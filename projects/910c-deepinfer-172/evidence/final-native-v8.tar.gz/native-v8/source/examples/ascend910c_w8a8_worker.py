"""Resident native DP2/TP8/EP16 workers; file IPC is under the project root."""
import argparse
import json
import os
from pathlib import Path
import time


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--model-dir',required=True)
    p.add_argument('--control-dir',type=Path,required=True)
    p.add_argument('--tp-size',type=int,default=8)
    p.add_argument('--slots-per-dp',type=int,default=4)
    p.add_argument('--max-tokens',type=int,default=34816)
    p.add_argument('--chunk-size',type=int,default=512)
    p.add_argument('--prefix-tokens',type=int,default=29568)
    args=p.parse_args()
    rank=int(os.environ['LOCAL_RANK'])
    os.environ['ASCEND_RT_VISIBLE_DEVICES']=str(rank)
    import torch
    import torch.distributed as dist
    import torch_npu
    from deepinfer.npu_ops.dsa910c import load_ops
    from deepinfer.engine.ascend_w8a8_serving import NativeServingRunner
    load_ops()
    torch.npu.set_device(0)
    dist.init_process_group('hccl')
    tp_group=None
    for first in range(0,dist.get_world_size(),args.tp_size):
        group=dist.new_group(list(range(first,first+args.tp_size)),backend='hccl')
        if first<=rank<first+args.tp_size:
            tp_group=group
    if os.environ.get('DEEPINFER_910C_MC2')=='1':
        from deepinfer.npu_ops.mc2_910c import initialize_mc2_group
        initialize_mc2_group()
    args.control_dir.mkdir(parents=True,exist_ok=True)
    progress=lambda event: print(json.dumps({'rank':rank,**event}),flush=True)
    runner=NativeServingRunner(args.model_dir,tp_group=tp_group,slots_per_dp=args.slots_per_dp,
        prefix_tokens=args.prefix_tokens,device='npu:0',max_tokens=args.max_tokens,
        chunk_size=args.chunk_size,progress=progress)
    dist.barrier()
    (args.control_dir/f'ready-rank{rank}.json').write_text(json.dumps({'rank':rank,'state':'READY'}))
    previous=None
    while True:
        current=args.control_dir/'current.json'
        if not current.exists():
            time.sleep(.02);continue
        command=json.loads(current.read_text())
        if command['id']==previous:
            time.sleep(.01);continue
        previous=command['id']
        directory=args.control_dir/'jobs'/previous
        job=json.loads((directory/'request.json').read_text())
        try:
            runner.run(job,directory)
        except Exception:
            import traceback
            (directory/f'error-rank{rank}.txt').write_text(traceback.format_exc())
            raise


if __name__=='__main__':
    main()
