# SPDX-License-Identifier: Apache-2.0
"""Native MC2 dispatch/GMM/combine using the pinned Ascend A3 operator ABI.

The ABI is adapted from the image's Apache-2.0 TokenDispatcherWithMC2.
No vendor runtime/config/parallel-state Python modules are imported. DeepInfer
owns the HCCL group, INT8 expert bank, routing and token capacity.
"""
import torch
import torch.distributed as dist

_MC2_GROUP=None


def initialize_mc2_group(buffer_mib=2560):
    """Use a dedicated MC2 communicator with the documented pg_options API.

    The A3 kernel reported 2,145,386,496 bytes required at global_bs=4096;
    the normal HCCL group's default200MiB window is insufficient. Restrict
    the larger window to MC2 instead of multiplying it across TP/control.
    """
    global _MC2_GROUP
    if _MC2_GROUP is None:
        import torch_npu
        options=torch_npu._C._distributed_c10d.ProcessGroupHCCL.Options()
        options.hccl_config={'hccl_buffer_size':buffer_mib}
        _MC2_GROUP=dist.new_group(list(range(dist.get_world_size())),backend='hccl',pg_options=options)
        dist.barrier(group=_MC2_GROUP)
    return _MC2_GROUP


class NativeMC2:
    def __init__(self,group=None):
        if _MC2_GROUP is None:
            raise RuntimeError('initialize_mc2_group() before constructing the native MC2 model')
        self.group=_MC2_GROUP
        self.rank=dist.get_rank(self.group)
        self.world=dist.get_world_size(self.group)
        self.name=self.group._get_backend(torch.device('npu')).get_hccl_comm_name(self.rank)

    def __call__(self,x,ids,weights,bank,*,num_experts,global_bs):
        import torch_npu
        # The A3 profile passes the TP ABI fields even though experts are EP.
        common=dict(group_ep=self.name,ep_world_size=self.world,ep_rank_id=self.rank,
            expert_shard_type=0,shared_expert_rank_num=0,moe_expert_num=num_experts,
            global_bs=global_bs,group_tp=self.name,tp_world_size=1,tp_rank_id=0,comm_alg='')
        outputs=torch_npu.npu_moe_distribute_dispatch_v2(x=x,expert_ids=ids.int(),
            scales=None,quant_mode=0,expert_token_nums_type=0,**common)
        expanded,_,assist,groups,ep_counts,tp_counts,expand_scales=outputs[:7]
        values=bank.forward_grouped(expanded,groups,group_list_type=0)
        return torch_npu.npu_moe_distribute_combine_v2(expand_x=values,expert_ids=ids.int(),
            expert_scales=weights.float(),ep_send_counts=ep_counts,tp_send_counts=tp_counts,
            assist_info_for_combine=assist,expand_scales=expand_scales,comm_quant_mode=0,**common)
