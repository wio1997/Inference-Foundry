# Multi-stage build for sgl-router.
#
# Three stages, each scoped to its caching contract:
#   1. chef   — generate a `recipe.json` describing the dep graph.
#   2. builder — compile deps from the recipe, then the workspace.
#   3. runtime — distroless cc-debian12 with the stripped binary.
#
# The `cargo-chef` indirection is the canonical Rust multi-stage cache
# pattern: the recipe step's inputs are JUST `Cargo.toml` + `Cargo.lock`,
# so a source-only change produces a recipe-layer cache hit and the
# heavy `cook --release` step is reused untouched. A naive "copy
# manifests → cargo fetch → copy src" approach caches only the fetched
# registry; every source change still recompiles every dep.
#
# `sgl-router/Cargo.lock` is committed, and every cargo step
# below runs with `--locked`, so the image ships exactly the dependency
# graph CI checked, tested, and license-audited.
#
# Build (from the repo root):
#   docker build -f docker/sgl-router.Dockerfile -t sgl-router:dev .
# Run:
#   docker run --rm -p 8090:8090 \
#       -v $(pwd)/docker/sgl-router.sample.yaml:/etc/sgl-router/sgl-router.yaml \
#       sgl-router:dev --config /etc/sgl-router/sgl-router.yaml
#
# Image budget: < 100 MB stripped (M6 acceptance). Verify with
#   `docker image inspect sgl-router:dev --format '{{.Size}}'`.
#
# FIPS 140-3 build (aws-lc-rs FIPS module as the TLS provider; see the `fips`
# feature in sgl-router/Cargo.toml). The module is statically linked, so the
# runtime image needs nothing extra; RUNTIME_BASE_IMAGE may point at a FIPS
# base for the OS packages:
#   docker build -f docker/sgl-router.Dockerfile --build-arg CARGO_FEATURES=fips \
#       -t sgl-router:fips .

ARG RUST_VERSION=1.92
ARG DEBIAN_VERSION=bookworm
ARG RUNTIME_BASE_IMAGE=gcr.io/distroless/cc-debian12:nonroot

######################## STAGE 1 — chef recipe ##########################
FROM rust:${RUST_VERSION}-${DEBIAN_VERSION} AS chef
RUN cargo install cargo-chef --locked --version ^0.1
WORKDIR /work/sgl-router
COPY sgl-router/Cargo.toml sgl-router/Cargo.lock ./
COPY sgl-router/sgl-kv-indexer/Cargo.toml sgl-kv-indexer/Cargo.toml
# sglang-processor is a path dependency that inherits from the rust/ workspace manifest.
COPY rust/Cargo.toml /work/rust/Cargo.toml
COPY rust/sglang-api-types /work/rust/sglang-api-types
COPY rust/sglang-runtime-v1-types /work/rust/sglang-runtime-v1-types
COPY rust/sglang-processor/Cargo.toml /work/rust/sglang-processor/Cargo.toml
# Stub a minimal src tree so cargo can see the workspace targets, then
# prepare the chef recipe.
RUN mkdir -p src sgl-kv-indexer/src/bin /work/rust/sglang-processor/src \
    && touch /work/rust/sglang-processor/src/lib.rs \
    && echo "fn main() {}" > src/main.rs \
    && echo "" > src/lib.rs \
    && echo "" > sgl-kv-indexer/src/lib.rs \
    && echo "fn main() {}" > sgl-kv-indexer/src/bin/kv-indexer-server.rs \
    && echo "fn main() {}" > sgl-kv-indexer/src/bin/kv-indexer-bridge.rs \
    && cargo chef prepare --recipe-path recipe.json \
    && rm -rf src sgl-kv-indexer/src

######################## STAGE 2 — builder ##############################
FROM rust:${RUST_VERSION}-${DEBIAN_VERSION} AS builder
# Comma-separated cargo features; empty for the default build. `fips` also
# needs the aws-lc-fips-sys toolchain (cmake, Go for the delocator, clang).
ARG CARGO_FEATURES=""
RUN apt-get update \
    && apt-get install -y --no-install-recommends protobuf-compiler \
    && case ",${CARGO_FEATURES}," in \
         *,fips,*) apt-get install -y --no-install-recommends cmake golang-go clang libclang-dev ;; \
       esac \
    && rm -rf /var/lib/apt/lists/* \
    && cargo install cargo-chef --locked --version ^0.1
WORKDIR /work/sgl-router

# `dynamo-tokenizers` pulls in `pcre2-sys`, whose build.rs links the SYSTEM
# libpcre2-8 whenever pkg-config finds it (it does here — the rust:bookworm
# base ships libpcre2-dev). That dynamic dep is absent from the distroless
# runtime, so the binary fails at startup with "libpcre2-8.so.0: cannot open
# shared object file". Force pcre2-sys to compile its vendored PCRE2 and link
# it statically, keeping the runtime self-contained.
ENV PCRE2_SYS_STATIC=1

COPY --from=chef /work/sgl-router/recipe.json ./recipe.json
COPY sgl-router/sgl-kv-indexer/Cargo.toml sgl-kv-indexer/Cargo.toml
# The recipe omits path dependencies outside this workspace, so cook against a
# stub of sglang-processor; its real sources arrive with the router's below.
COPY rust/Cargo.toml /work/rust/Cargo.toml
COPY rust/sglang-api-types /work/rust/sglang-api-types
COPY rust/sglang-runtime-v1-types /work/rust/sglang-runtime-v1-types
COPY rust/sglang-processor/Cargo.toml /work/rust/sglang-processor/Cargo.toml
RUN mkdir -p /work/rust/sglang-processor/src && touch /work/rust/sglang-processor/src/lib.rs

# Cook (compile + cache) the dep graph from the recipe. The recipe carries every
# workspace member's manifest and the lockfile, so chef recreates the Indexer's
# source stubs itself.
RUN cargo chef cook --locked --release --recipe-path recipe.json \
    ${CARGO_FEATURES:+--features "$CARGO_FEATURES"}

# Now bring in the real sources and the manifests they need.
COPY sgl-router/Cargo.toml sgl-router/Cargo.lock ./
COPY sgl-router/src ./src
COPY sgl-router/sgl-kv-indexer/Cargo.toml sgl-kv-indexer/Cargo.toml
COPY sgl-router/sgl-kv-indexer/build.rs sgl-kv-indexer/build.rs
COPY sgl-router/sgl-kv-indexer/proto sgl-kv-indexer/proto
COPY sgl-router/sgl-kv-indexer/src sgl-kv-indexer/src
COPY rust/sglang-processor/src /work/rust/sglang-processor/src

RUN touch sgl-kv-indexer/build.rs /work/rust/sglang-processor/src/lib.rs \
    && cargo build --locked --release --bin sgl-router \
       ${CARGO_FEATURES:+--features "$CARGO_FEATURES"} \
    && strip target/release/sgl-router

######################## STAGE 3 — runtime ##############################
FROM ${RUNTIME_BASE_IMAGE} AS runtime

COPY --from=builder /work/sgl-router/target/release/sgl-router /usr/local/bin/sgl-router

# Default config path; mount your own via `-v <host-path>:/etc/sgl-router`.
ENV SGL_ROUTER_CONFIG=/etc/sgl-router/sgl-router.yaml
EXPOSE 8090

# distroless `nonroot` runs as uid 65532. The router doesn't need root.
# Numeric so a RUNTIME_BASE_IMAGE without a `nonroot` passwd entry still works.
USER 65532:65532

ENTRYPOINT ["/usr/local/bin/sgl-router"]
