export const InternS1Deployment = () => {
  const options = {
    hardware: {
      name: 'hardware',
      title: 'Hardware Platform',
      items: [
        { id: 'b200', label: 'B200', default: true },
        { id: 'b300', label: 'B300', default: false },
        { id: 'h100', label: 'H100', default: false },
        { id: 'h200', label: 'H200', default: false },
        { id: 'xeon', label: 'XEON', default: false },
      ],
    },
    modelsize: {
      name: 'modelsize',
      title: 'Model Size',
      items: [
        { id: 'S1', label: '235B', subtitle: 'MoE', default: true },
        { id: 'S1-mini', label: '8B', subtitle: 'Dense', default: false },
      ],
    },
    quantization: {
      name: 'quantization',
      title: 'Quantization',
      items: [
        { id: 'bf16', label: 'BF16', default: true },
        { id: 'fp8', label: 'FP8', default: false },
      ],
    },
    reasoning: {
      name: 'reasoning',
      title: 'Reasoning Parser',
      items: [
        { id: 'disabled', label: 'Disabled', default: true },
        { id: 'enabled', label: 'Enabled', default: false },
      ],
    },
    toolcall: {
      name: 'toolcall',
      title: 'Tool Call Parser',
      items: [
        { id: 'disabled', label: 'Disabled', default: true },
        { id: 'enabled', label: 'Enabled', default: false },
      ],
    },
  };

  const modelConfigs = {
    S1: {
      baseName: 'S1',
      h100: { bf16: { tp: 8 }, fp8: { tp: 8, ep: 2 } },
      h200: { bf16: { tp: 8 }, fp8: { tp: 8, ep: 2 } },
      b200: { bf16: { tp: 8 }, fp8: { tp: 8, ep: 2 } },
      b300: { bf16: { tp: 8 }, fp8: { tp: 8, ep: 2 } },
      xeon: { bf16: { tp: 6 }, fp8: { tp: 6 } },
    },
    'S1-mini': {
      baseName: 'S1-mini',
      h100: { bf16: { tp: 1 }, fp8: { tp: 1 } },
      h200: { bf16: { tp: 1 }, fp8: { tp: 1 } },
      b200: { bf16: { tp: 1 }, fp8: { tp: 1 } },
      b300: { bf16: { tp: 1 }, fp8: { tp: 1 } },
      xeon: { bf16: { tp: 1 }, fp8: { tp: 1 } },
    },
  };

  const resolveItems = (option, vals) =>
    typeof option.getDynamicItems === 'function' ? option.getDynamicItems(vals) : option.items;

  const getInitialState = () => {
    const initialState = {};
    for (const [key, option] of Object.entries(options)) {
      const items = resolveItems(option, initialState);
      const defaultItem = items.find((item) => item.default && !item.disabled) || items.find((item) => !item.disabled) || items[0];
      initialState[key] = defaultItem.id;
    }
    return initialState;
  };

  const [values, setValues] = useState(getInitialState);
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const checkDarkMode = () => {
      const html = document.documentElement;
      const isDarkMode =
        html.classList.contains('dark') ||
        html.getAttribute('data-theme') === 'dark' ||
        html.style.colorScheme === 'dark';
      setIsDark(isDarkMode);
    };
    checkDarkMode();
    const observer = new MutationObserver(checkDarkMode);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class', 'data-theme', 'style'],
    });
    return () => observer.disconnect();
  }, []);

  const handleRadioChange = (optionName, value) => {
    setValues((prev) => ({ ...prev, [optionName]: value }));
  };

  useEffect(() => {
    setValues((prev) => {
      const next = { ...prev };
      for (const [key, option] of Object.entries(options)) {
        if (typeof option.getDynamicItems !== 'function') continue;
        const items = option.getDynamicItems(next);
        const current = items.find((item) => item.id === next[key]);
        if (!current || current.disabled) {
          const fallback = items.find((item) => item.default && !item.disabled) || items.find((item) => !item.disabled);
          if (fallback) next[key] = fallback.id;
        }
      }
      return next;
    });
  }, [values.hardware]);

  const generateCommand = () => {
    const { hardware, modelsize, quantization, reasoning, toolcall } = values;
    const modelConfig = modelConfigs[modelsize];
    const hwConfig = modelConfig?.[hardware]?.[quantization];
    if (!hwConfig) {
      return '# Please select a valid hardware and quantization combination';
    }

    const isXeon = hardware === 'xeon';
    const quantSuffix = quantization === 'fp8' ? '-FP8' : '';
    const modelName = `internlm/Intern-${modelConfig.baseName}${quantSuffix}`;

    const flags = [];
    flags.push(`  --model ${modelName}`);
    if (isXeon) {
      flags.push('  --device cpu');
      flags.push('  --disable-overlap-schedule');
    }
    if (hwConfig.tp > 1) flags.push(`  --tp ${hwConfig.tp}`);
    if (hwConfig.ep) flags.push(`  --ep ${hwConfig.ep}`);
    if (quantization === 'fp8') flags.push(`  --tokenizer-path internlm/Intern-${modelConfig.baseName}`);
    if (reasoning === 'enabled') flags.push('  --reasoning-parser interns1');
    if (toolcall === 'enabled') flags.push('  --tool-call-parser interns1');
    flags.push('  --trust-remote-code');
    if (hardware === 'b300') flags.push('  --attention-backend flashinfer');

    return `python -m sglang.launch_server \\\n${flags.join(' \\\n')}`;
  };

  const containerStyle = { maxWidth: '900px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '4px' };
  const cardStyle = { padding: '8px 12px', border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`, borderLeft: `3px solid ${isDark ? '#E85D4D' : '#D45D44'}`, borderRadius: '4px', display: 'flex', alignItems: 'center', gap: '12px', background: isDark ? '#1f2937' : '#fff' };
  const titleStyle = { fontSize: '13px', fontWeight: '600', minWidth: '140px', flexShrink: 0, color: isDark ? '#e5e7eb' : 'inherit' };
  const itemsStyle = { display: 'flex', rowGap: '2px', columnGap: '6px', flexWrap: 'wrap', alignItems: 'center', flex: 1 };
  const labelBaseStyle = { padding: '4px 10px', border: `1px solid ${isDark ? '#9ca3af' : '#d1d5db'}`, borderRadius: '3px', cursor: 'pointer', display: 'inline-flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', fontWeight: '500', fontSize: '13px', transition: 'all 0.2s', userSelect: 'none', minWidth: '45px', textAlign: 'center', flex: 1, background: isDark ? '#374151' : '#fff', color: isDark ? '#e5e7eb' : 'inherit' };
  const checkedStyle = { background: '#D45D44', color: 'white', borderColor: '#D45D44' };
  const subtitleStyle = { display: 'block', fontSize: '9px', marginTop: '1px', lineHeight: '1.1', opacity: 0.7 };
  const commandDisplayStyle = { flex: 1, padding: '12px 16px', background: isDark ? '#111827' : '#f5f5f5', borderRadius: '6px', fontFamily: "'Menlo', 'Monaco', 'Courier New', monospace", fontSize: '12px', lineHeight: '1.5', color: isDark ? '#e5e7eb' : '#374151', whiteSpace: 'pre-wrap', overflowX: 'auto', margin: 0, border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}` };

  return (
    <div style={containerStyle} className="not-prose">
      {Object.entries(options).map(([key, option]) => {
        const items = resolveItems(option, values);
        return (
        <div key={key} style={cardStyle}>
          <div style={titleStyle}>{option.title}</div>
          <div style={itemsStyle}>
            {items.map((item) => {
              const isChecked = values[option.name] === item.id;
              return (
                <label key={item.id} title={item.disabledReason || ''} style={{ ...labelBaseStyle, ...(isChecked ? checkedStyle : {}), ...(item.disabled ? { cursor: 'not-allowed', opacity: 0.5 } : {}) }}>
                  <input
                    type="radio"
                    name={option.name}
                    value={item.id}
                    checked={isChecked}
                    disabled={Boolean(item.disabled)}
                    onChange={() => !item.disabled && handleRadioChange(option.name, item.id)}
                    style={{ display: 'none' }}
                  />
                  {item.label}
                  {item.subtitle && (
                    <small style={{ ...subtitleStyle, color: isChecked ? 'rgba(255,255,255,0.85)' : 'inherit' }}>
                      {item.subtitle}
                    </small>
                  )}
                </label>
              );
            })}
          </div>
        </div>
        );
      })}
      <div style={cardStyle}>
        <div style={titleStyle}>Run this Command:</div>
        <pre style={commandDisplayStyle}>{generateCommand()}</pre>
      </div>
    </div>
  );
};
