export const Gemma4Deployment = () => {
  const options = {
    modelSize: {
      name: 'modelSize',
      title: 'Model Variant',
      items: [
        { id: 'e2b', label: 'E2B (~2B)', default: false },
        { id: 'e4b', label: 'E4B (~4B)', default: true },
        { id: '12b', label: '12B (Dense)', default: false },
        { id: '31b', label: '31B (Dense)', default: false },
        { id: '26b-a4b', label: '26B-A4B (MoE)', default: false },
      ]
    },
    checkpoint: {
      name: 'checkpoint',
      title: 'Checkpoint',
      items: [
        { id: 'standard', label: 'Standard', subtitle: 'BF16', default: true },
        { id: 'qat', label: 'QAT', subtitle: 'q4_0-unquantized', default: false },
      ]
    },
    hardware: {
      name: 'hardware',
      title: 'Hardware Platform',
      getDynamicItems: (values) => {
        const size = values.modelSize;
        const showMI300X = size === '31b' || size === '26b-a4b';
        const showXeon = ['e2b', 'e4b', '31b', '26b-a4b'].includes(size);
        return [
          { id: 'h200', label: 'H200', default: true },
          { id: 'b200', label: 'B200', default: false },
          { id: 'b300', label: 'B300', default: false },
          { id: 'mi300x', label: 'MI300X', default: false, disabled: !showMI300X },
          { id: 'xeon', label: 'XEON', default: false, disabled: !showXeon },
          { id: 'arc_b', label: 'BMG', default: false },
        ];
      }
    },
    reasoning: {
      name: 'reasoning',
      title: 'Reasoning Parser',
      items: [
        { id: 'disabled', label: 'Disabled', default: false },
        { id: 'enabled', label: 'Enabled', default: true }
      ],
      commandRule: (value) => value === 'enabled' ? '--reasoning-parser gemma4' : null
    },
    toolcall: {
      name: 'toolcall',
      title: 'Tool Call Parser',
      items: [
        { id: 'disabled', label: 'Disabled', default: false },
        { id: 'enabled', label: 'Enabled', default: true }
      ],
      commandRule: (value) => value === 'enabled' ? '--tool-call-parser gemma4' : null
    },
    speculative: {
      name: 'speculative',
      title: 'Speculative Decoding (MTP)',
      condition: (values) => !['mi300x'].includes(values.hardware),
      items: [
        { id: 'disabled', label: 'Disabled', subtitle: 'Baseline', default: true },
        { id: 'enabled', label: 'Enabled', subtitle: 'Lower Latency', default: false }
      ]
    },
  };

  const modelConfigs = {
    h200: {
      e2b: { tp: 1, mem: 0.85 },
      e4b: { tp: 1, mem: 0.85 },
      '12b': { tp: 1, mem: 0.85 },
      '31b': { tp: 2, mem: 0.85 },
      '26b-a4b': { tp: 1, mem: 0.85 },
    },
    b200: {
      e2b: { tp: 1, mem: 0.9 },
      e4b: { tp: 1, mem: 0.9 },
      '12b': { tp: 1, mem: 0.9 },
      '31b': { tp: 1, mem: 0.9 },
      '26b-a4b': { tp: 1, mem: 0.75 },
    },
    b300: {
      e2b: { tp: 1, mem: 0.9 },
      e4b: { tp: 1, mem: 0.9 },
      '12b': { tp: 1, mem: 0.9 },
      '31b': { tp: 1, mem: 0.9 },
      '26b-a4b': { tp: 1, mem: 0.9 },
    },
    mi300x: {
      '31b': { tp: 1, mem: 0.80 },
      '26b-a4b': { tp: 1, mem: 0.80 },
    },
    arc_b: {
      '31b': { tp: 4, mem: 0.80 },
      '26b-a4b': { tp: 4, mem: 0.75 },
    },
    xeon: {
      e2b: { tp: 1, mem: 0.9 },
      e4b: { tp: 1, mem: 0.9 },
      '31b': { tp: 4, mem: 0.5 },
      '26b-a4b': { tp: 2, mem: 0.5 },
    },
  };

  const generateCommand = (values) => {
    const { hardware, modelSize } = values;

    const hwConfig = modelConfigs[hardware]?.[modelSize];
    if (!hwConfig) return `# Error: Unknown hardware/model combination`;

    let { tp, mem } = hwConfig;

    const modelNames = {
      'e2b': 'google/gemma-4-E2B-it',
      'e4b': 'google/gemma-4-E4B-it',
      '12b': 'google/gemma-4-12B-it',
      '31b': 'google/gemma-4-31B-it',
      '26b-a4b': 'google/gemma-4-26B-A4B-it',
    };

    // QAT releases keep bf16 weights (q4_0-unquantized), so the only change is
    // the model-path suffix; TP/memory requirements match the standard checkpoints.
    const qatSuffix = values.checkpoint === 'qat' ? '-qat-q4_0-unquantized' : '';
    const modelPath = `${modelNames[modelSize]}${qatSuffix}`;

    const mtpEnabled = values.speculative === 'enabled';
    if (mtpEnabled && modelSize === '26b-a4b' && hardware !== 'mi300x' && hardware !== 'xeon') {
      tp = 2;
    }

    let cmd = `sglang serve --model-path ${modelPath}`;
    if (hardware === 'xeon') {
      cmd += ` \\\n  --device cpu \\\n  --disable-overlap-schedule`;
    }
    if (tp > 1) {
      cmd += ` \\\n  --tp ${tp}`;
    }

    Object.entries(options).forEach(([key, option]) => {
      if (key === 'modelSize' || key === 'hardware') return;
      if (option.commandRule) {
        const rule = option.commandRule(values[key]);
        if (rule) cmd += ` \\\n  ${rule}`;
      }
    });

    if (mtpEnabled) {
      if (hardware === 'xeon') {
        cmd += ` \\\n  --speculative-algorithm NGRAM`;
      } else {
        cmd += ` \\\n  --speculative-algorithm NEXTN`;
        cmd += ` \\\n  --speculative-draft-model-path ${modelPath}-assistant`;
        cmd += ` \\\n  --speculative-num-steps 5`;
        cmd += ` \\\n  --speculative-num-draft-tokens 6`;
        cmd += ` \\\n  --speculative-eagle-topk 1`;
      }
    }

    if (hardware === 'b300') {
      cmd += ` \\\n  --attention-backend triton`;
    }

    if (hardware === 'arc_b') {
      cmd += ` \\\n  --device xpu`;
    }

    cmd += ` \\\n  --mem-fraction-static ${mem}`;
    cmd += ` \\\n  --host 0.0.0.0 --port 30000`;

    return cmd;
  };

  const getInitialState = () => {
    const initialState = {};
    Object.entries(options).forEach(([key, option]) => {
      if (option.type === 'checkbox') {
        initialState[key] = (option.items || [])
          .filter((item) => item.default)
          .map((item) => item.id);
        return;
      }
      if (option.type === 'text') {
        initialState[key] = option.default || '';
        return;
      }
      let items = option.items || [];
      if (option.getDynamicItems) {
        const defaultValues = {};
        Object.entries(options).forEach(([innerKey, innerOption]) => {
          if (innerOption.type === 'checkbox') {
            defaultValues[innerKey] = (innerOption.items || [])
              .filter((item) => item.default)
              .map((item) => item.id);
          } else if (innerOption.type === 'text') {
            defaultValues[innerKey] = innerOption.default || '';
          } else if (innerOption.items && innerOption.items.length > 0) {
            const defaultItem = innerOption.items.find((item) => item.default);
            defaultValues[innerKey] = defaultItem ? defaultItem.id : innerOption.items[0].id;
          }
        });
        items = option.getDynamicItems(defaultValues);
      }
      const defaultItem = items && items.find((item) => item.default);
      initialState[key] = defaultItem ? defaultItem.id : items && items[0] ? items[0].id : '';
    });
    return initialState;
  };

  const [values, setValues] = useState(getInitialState);
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    const checkDarkMode = () => {
      const html = document.documentElement;
      const isDarkMode =
        html.classList.contains('dark') ||
        html.getAttribute('data-theme') === 'dark' ||
        html.style.colorScheme === 'dark';
      setIsDark(isDarkMode);
    };
    checkDarkMode();
    const observer = new MutationObserver(checkDarkMode);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class', 'data-theme', 'style'],
    });
    return () => observer.disconnect();
  }, []);

  const handleRadioChange = (optionName, value) => {
    setValues((prev) => {
      if (prev.hardware === 'arc_b' && optionName === 'modelSize' && !['31b', '26b-a4b'].includes(value)) {
        return prev;
      }
      if (prev.hardware === 'arc_b' && optionName === 'checkpoint' && value !== 'standard') {
        return prev;
      }
      if (prev.hardware === 'arc_b' && optionName === 'speculative' && value !== 'disabled') {
        return prev;
      }

      const next = { ...prev, [optionName]: value };
      if (optionName === 'hardware' && value === 'arc_b') {
        if (!['31b', '26b-a4b'].includes(next.modelSize)) {
          next.modelSize = '31b';
        }
        next.checkpoint = 'standard';
        next.speculative = 'disabled';
      }
      if (optionName === 'hardware' && value === 'xeon') {
        next.checkpoint = 'standard';
      }
      return next;
    });
  };

  const handleCheckboxChange = (optionName, itemId, isChecked) => {
    setValues((prev) => {
      const currentValues = prev[optionName] || [];
      if (isChecked) {
        return { ...prev, [optionName]: [...currentValues, itemId] };
      }
      return {
        ...prev,
        [optionName]: currentValues.filter((id) => id !== itemId),
      };
    });
  };

  const handleTextChange = (optionName, value) => {
    setValues((prev) => ({ ...prev, [optionName]: value }));
  };

  const command = generateCommand(values);

  const containerStyle = {
    maxWidth: '900px',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
  };
  const cardStyle = {
    padding: '8px 12px',
    border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`,
    borderLeft: `3px solid ${isDark ? '#E85D4D' : '#D45D44'}`,
    borderRadius: '4px',
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    background: isDark ? '#1f2937' : '#fff',
  };
  const titleStyle = {
    fontSize: '13px',
    fontWeight: '600',
    minWidth: '140px',
    flexShrink: 0,
    color: isDark ? '#e5e7eb' : 'inherit',
  };
  const itemsStyle = {
    display: 'flex',
    rowGap: '2px',
    columnGap: '6px',
    flexWrap: 'wrap',
    alignItems: 'center',
    flex: 1,
  };
  const labelBaseStyle = {
    padding: '4px 10px',
    border: `1px solid ${isDark ? '#9ca3af' : '#d1d5db'}`,
    borderRadius: '3px',
    cursor: 'pointer',
    display: 'inline-flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: '500',
    fontSize: '13px',
    transition: 'all 0.2s',
    userSelect: 'none',
    minWidth: '45px',
    textAlign: 'center',
    flex: 1,
    background: isDark ? '#374151' : '#fff',
    color: isDark ? '#e5e7eb' : 'inherit',
  };
  const checkedStyle = {
    background: '#D45D44',
    color: 'white',
    borderColor: '#D45D44',
  };
  const disabledStyle = {
    cursor: 'not-allowed',
    opacity: 0.5,
  };
  const subtitleStyle = {
    display: 'block',
    fontSize: '9px',
    marginTop: '1px',
    lineHeight: '1.1',
    opacity: 0.7,
  };
  const textInputStyle = {
    flex: 1,
    padding: '8px 10px',
    borderRadius: '4px',
    border: `1px solid ${isDark ? '#4b5563' : '#d1d5db'}`,
    background: isDark ? '#111827' : '#fff',
    color: isDark ? '#e5e7eb' : '#111827',
    fontSize: '13px',
  };
  const commandDisplayStyle = {
    flex: 1,
    padding: '12px 16px',
    background: isDark ? '#111827' : '#f5f5f5',
    borderRadius: '6px',
    fontFamily: "'Menlo', 'Monaco', 'Courier New', monospace",
    fontSize: '12px',
    lineHeight: '1.5',
    color: isDark ? '#e5e7eb' : '#374151',
    whiteSpace: 'pre-wrap',
    overflowX: 'auto',
    margin: 0,
    border: `1px solid ${isDark ? '#374151' : '#e5e7eb'}`,
  };

  return (
    <div style={containerStyle} className="not-prose">
      {Object.entries(options).map(([key, option]) => {
        if (option.condition && !option.condition(values)) {
          return null;
        }
        const items = option.getDynamicItems ? option.getDynamicItems(values) : option.items || [];
        return (
          <div key={key} style={cardStyle}>
            <div style={titleStyle}>{option.title}</div>
            <div style={itemsStyle}>
              {option.type === 'text' ? (
                <input
                  type="text"
                  value={values[option.name] || ''}
                  placeholder={option.placeholder || ''}
                  onChange={(event) => handleTextChange(option.name, event.target.value)}
                  style={textInputStyle}
                />
              ) : option.type === 'checkbox' ? (
                (option.items || []).map((item) => {
                  const isChecked = (values[option.name] || []).includes(item.id);
                  const isDisabled =
                    item.required ||
                    (typeof item.disabledWhen === 'function' && item.disabledWhen(values));
                  return (
                    <label
                      key={item.id}
                      title={item.disabledReason || ''}
                      style={{
                        ...labelBaseStyle,
                        ...(isChecked ? checkedStyle : {}),
                        ...(isDisabled ? disabledStyle : {}),
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        disabled={isDisabled}
                        onChange={(event) =>
                          handleCheckboxChange(option.name, item.id, event.target.checked)
                        }
                        style={{ display: 'none' }}
                      />
                      {item.label}
                      {item.subtitle && (
                        <small
                          style={{
                            ...subtitleStyle,
                            color: isChecked ? 'rgba(255,255,255,0.85)' : 'inherit',
                          }}
                        >
                          {item.subtitle}
                        </small>
                      )}
                    </label>
                  );
                })
              ) : (
                items.map((item) => {
                  const isChecked = values[option.name] === item.id;
                  const isArcBModelLocked =
                    values.hardware === 'arc_b' &&
                    option.name === 'modelSize' &&
                    !['31b', '26b-a4b'].includes(item.id);
                  const isArcBCheckpointLocked =
                    values.hardware === 'arc_b' &&
                    option.name === 'checkpoint' &&
                    item.id !== 'standard';
                  const isArcBSpeculativeLocked =
                    values.hardware === 'arc_b' &&
                    option.name === 'speculative' &&
                    item.id !== 'disabled';
                  const isXeonQatLocked =
                    values.hardware === 'xeon' &&
                    option.name === 'checkpoint' &&
                    item.id === 'qat';
                  const isXeon12bLocked =
                    values.hardware === 'xeon' &&
                    option.name === 'modelSize' &&
                    item.id === '12b';
                  const isDisabled = Boolean(
                    item.disabled || isArcBModelLocked || isArcBCheckpointLocked ||
                    isArcBSpeculativeLocked || isXeonQatLocked || isXeon12bLocked
                  );
                  return (
                    <label
                      key={item.id}
                      title={item.disabledReason || ''}
                      style={{
                        ...labelBaseStyle,
                        ...(isChecked ? checkedStyle : {}),
                        ...(isDisabled ? disabledStyle : {}),
                      }}
                    >
                      <input
                        type="radio"
                        name={option.name}
                        value={item.id}
                        checked={isChecked}
                        disabled={isDisabled}
                        onChange={() => !isDisabled && handleRadioChange(option.name, item.id)}
                        style={{ display: 'none' }}
                      />
                      {item.label}
                      {item.subtitle && (
                        <small
                          style={{
                            ...subtitleStyle,
                            color: isChecked ? 'rgba(255,255,255,0.85)' : 'inherit',
                          }}
                        >
                          {item.subtitle}
                        </small>
                      )}
                    </label>
                  );
                })
              )}
            </div>
          </div>
        );
      })}
      <div style={cardStyle}>
        <div style={titleStyle}>Run this Command:</div>
        <pre style={commandDisplayStyle}>{command}</pre>
      </div>
    </div>
  );
};
