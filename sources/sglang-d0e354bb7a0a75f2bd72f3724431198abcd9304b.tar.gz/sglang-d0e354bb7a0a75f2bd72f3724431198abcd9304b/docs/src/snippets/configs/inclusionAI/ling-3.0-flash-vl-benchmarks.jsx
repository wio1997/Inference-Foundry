// Ling-3.0-flash-VL per-cell benchmark numbers, keyed by the same `match` tuple as
// ling-3.0-flash-vl.jsx cells. See _deployment.jsx for the speed/accuracy schema.
//
// Speed: bench_serving --flush-cache --random-range-ratio 1, temperature 0. Speed cards
// use the `random` dataset (text-only, isl 8192 / osl 1024) across LL (conc 1/16) and HT
// (conc 1024/4096); per-cell notes carry the separate `image` workload (one random 720p
// JPEG per request, +883 vision tokens, isl/osl 1024/1024, conc 1/16/64/128). TTFT/TPOT
// are P50; tokens_per_sec_per_gpu = total (input + output) token throughput ÷ GPU count.
// HT columns are queue-dominated because the KDA state cache caps concurrent requests
// (GB300 TP=4: 935; H200 TP=4: 314).
// Accuracy: sgl-eval MMMU-Pro, full 1730 examples, single-shot, thinking on (template
// default), temperature 0 / top_p 0.95.
export const benchmarks = [
  {
    match: { hw: "gb300", variant: "default", quant: "bf16", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    speed: [
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 1, num_prompts: 8 },
        ttft_ms: 190.51, tpot_ms: 3.37, tokens_per_sec_per_gpu: 612 },
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 16, num_prompts: 64 },
        ttft_ms: 1443.44, tpot_ms: 6.92, tokens_per_sec_per_gpu: 4335 },
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 1024, num_prompts: 2048 },
        ttft_ms: 41335.64, tpot_ms: 124.74, tokens_per_sec_per_gpu: 12586 },
    ],
    accuracy: { mmmu_pro_pct: 75.78 },
    notes: "4×GB300, TP=4. Speed: bench_serving --flush-cache, temperature 0; tok/s/GPU = total (input + output) token throughput ÷ 4. max-concurrency=4096 (8192 prompts): TTFT 555688.12 ms, TPOT 119.86 ms, 12296 tok/s/GPU. HT columns are queue-dominated (KDA state cache caps concurrent requests at 935 on this cell) — judge HT by TPOT/throughput, not TTFT. Image workload (one 720p JPEG per request, +883 vision tokens, in/out=1024/1024): conc 1: TTFT 320.99 ms, TPOT 3.91 ms, 173 tok/s/GPU; conc 16: TTFT 1490.73 ms, TPOT 6.53 ms, 1381 tok/s/GPU; conc 64: TTFT 3279.24 ms, TPOT 12.67 ms, 2996 tok/s/GPU; conc 128: TTFT 6887.76 ms, TPOT 15.56 ms, 4226 tok/s/GPU. Accuracy: MMMU-Pro (sgl-eval, 1730 examples, single-shot, thinking on, temperature 0 / top-p 0.95) measured on this recipe, stop rate 99.08%. The same checkpoint measured 77.86% at 2×GB300 TP=2 and 76.71% at 4×H200 TP=4.",
  },
  {
    match: { hw: "gb300", variant: "default", quant: "fp8", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    accuracy: { mmmu_pro_pct: 77.34, gsm8k_pct: 97.19 },
    notes: "GB300 TP=1, official FP8 checkpoint. MMMU-Pro 77.34% (stop 99.77%, truncated 0.23%, error 0) measured at TP=4 --ep 4 on 4×GB300; TP=1 serving smoke also verified on one GB300; GSM8K 97.19% (stop 100%) measured with online dynamic FP8 (--quantization fp8 on the BF16 checkpoint). BF16 on the same box: MMMU-Pro 75.78% (TP=4), GSM8K 97.35%. Speed (LL points, online-quantized measurement at TP=4, same protocol as the BF16 card): text 8192/1024 conc 1: TTFT 174.80 ms, TPOT 3.95 ms, 546 tok/s/GPU; conc 16: TTFT 981.25 ms, TPOT 7.49 ms, 4273 tok/s/GPU. Image 1024/1024 conc 1: TTFT 272.09 ms, TPOT 4.51 ms, 153 tok/s/GPU; conc 16: TTFT 1389.27 ms, TPOT 7.15 ms, 1369 tok/s/GPU. FP8 prefill (TTFT) is consistently faster than BF16 while TPOT is ~10% slower.",
  },
  { match: { hw: "b300", variant: "default", quant: "bf16", strategy: "balanced", nodes: "single" } },
  { match: { hw: "b200", variant: "default", quant: "bf16", strategy: "balanced", nodes: "single" } },
  {
    match: { hw: "h200", variant: "default", quant: "bf16", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    speed: [
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 1, num_prompts: 8 },
        ttft_ms: 232.57, tpot_ms: 3.32, tokens_per_sec_per_gpu: 634 },
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 16, num_prompts: 64 },
        ttft_ms: 1216.30, tpot_ms: 8.03, tokens_per_sec_per_gpu: 3898 },
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 1024, num_prompts: 2048 },
        ttft_ms: 153954.62, tpot_ms: 42.85, tokens_per_sec_per_gpu: 10405 },
    ],
    accuracy: { mmmu_pro_pct: 76.71 },
    notes: "4×H200, TP=4. Speed: bench_serving --flush-cache, temperature 0; tok/s/GPU = total (input + output) token throughput ÷ 4. max-concurrency=4096 (8192 prompts): TTFT 800898.01 ms, TPOT 46.01 ms, 10467 tok/s/GPU. HT columns are queue-dominated (KDA state cache caps concurrent requests at 314 on this cell) — judge HT by TPOT/throughput, not TTFT. Image workload (one 720p JPEG per request, +883 vision tokens, in/out=1024/1024): conc 1: TTFT 221.40 ms, TPOT 3.69 ms, 187 tok/s/GPU; conc 16: TTFT 1228.40 ms, TPOT 7.23 ms, 1378 tok/s/GPU; conc 64: TTFT 3932.72 ms, TPOT 13.02 ms, 2766 tok/s/GPU; conc 128: TTFT 6722.44 ms, TPOT 18.24 ms, 3737 tok/s/GPU. Accuracy: MMMU-Pro (sgl-eval, 1730 examples, single-shot, thinking on), stop rate 99.19%; also GSM8K 97.35% (stop rate 100%), eager, streaming, structured output, and auto parser resolution validated on this cell.",
  },
  { match: { hw: "h100", variant: "default", quant: "bf16", strategy: "balanced", nodes: "single" } },
  { match: { hw: "b300", variant: "default", quant: "fp8", strategy: "balanced", nodes: "single" } },
  { match: { hw: "b200", variant: "default", quant: "fp8", strategy: "balanced", nodes: "single" } },
  {
    match: { hw: "h200", variant: "default", quant: "fp8", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    accuracy: { mmmu_pro_pct: 77.34, gsm8k_pct: 97.19 },
    notes: "2×H200, TP=2, E4M3 block-[128,128] kernels engaged (measured: 126.2 GB checkpoint, ~59 GB weights per GPU, healthy in 581 s including download and first-time DeepGEMM compile). Serving smoke verified: text and image requests complete with finish_reason=stop and reasoning split. Accuracy: MMMU-Pro 77.34% measured on the official FP8 checkpoint at TP=4 --ep 4 on 4×GB300; GSM8K 97.19% measured with online dynamic FP8 (--quantization fp8 on the BF16 checkpoint) on the same serving path.",
  },
  { match: { hw: "h100", variant: "default", quant: "fp8", strategy: "balanced", nodes: "single" } },
  {
    match: { hw: "gb300", variant: "default", quant: "int4", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    accuracy: { mmmu_pro_pct: 77.51, gsm8k_pct: 96.97 },
    notes: "GB300 TP=1, auto-detected compressed-tensors int4 (group_size 32). Serving smoke verified at TP=1 and 2×GB300 TP=2: text and image requests complete with finish_reason=stop and reasoning split into reasoning_content. Accuracy measured on 2×B300, TP=2 (sgl-eval, single-shot, thinking on): MMMU-Pro 77.51% (1,730 examples, stop 98.96%, truncated 1.04%), GSM8K 96.97% (stop 100%).",
  },
  { match: { hw: "b300", variant: "default", quant: "int4", strategy: "balanced", nodes: "single" } },
  { match: { hw: "b200", variant: "default", quant: "int4", strategy: "balanced", nodes: "single" } },
  {
    match: { hw: "h200", variant: "default", quant: "int4", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    accuracy: { mmmu_pro_pct: 77.51, gsm8k_pct: 96.97 },
    notes: "1×H200 (141 GB), TP=1, auto-detected compressed-tensors int4 (W4A16 Marlin MoE; 121 GB GPU memory in use incl. KV pool). Serving smoke verified: text and image requests complete with finish_reason=stop and reasoning split. Accuracy measured on 2×B300, TP=2 (sgl-eval, single-shot, thinking on): MMMU-Pro 77.51% (stop 98.96%), GSM8K 96.97% (stop 100%).",
  },
  { match: { hw: "h100", variant: "default", quant: "int4", strategy: "balanced", nodes: "single" } },
  {
    match: { hw: "gb300", variant: "default", quant: "fp4", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    accuracy: { mmmu_pro_pct: 76.24, gsm8k_pct: 96.66 },
    notes: "GB300 TP=1, flashinfer_mxfp4 MoE backend (auto-selected). Serving smoke verified on one GB300 at TP=1 and on 2×GB300 at TP=2: text and image requests complete with finish_reason=stop and reasoning split. Accuracy measured on 2×B300, TP=2, without an explicit --moe-runner-backend flag (sgl-eval, single-shot, thinking on): MMMU-Pro 76.24% (1,730 examples, stop 98.96%, truncated 1.04%), GSM8K 96.66% (stop 100%).",
  },
  { match: { hw: "b300", variant: "default", quant: "fp4", strategy: "balanced", nodes: "single" } },
  { match: { hw: "b200", variant: "default", quant: "fp4", strategy: "balanced", nodes: "single" } },
  {
    match: { hw: "h200", variant: "default", quant: "fp4", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    accuracy: { mmmu_pro_pct: 76.24, gsm8k_pct: 96.66 },
    notes: "1×H200 (141 GB), TP=1, flashinfer_mxfp4 MoE backend (SM90 CUTLASS W4A16), auto-selected — verified without an explicit --moe-runner-backend flag (healthy in 330 s). Serving smoke verified: text request completes with finish_reason=stop and reasoning split. Accuracy measured on 2×B300, TP=2 (sgl-eval, single-shot, thinking on): MMMU-Pro 76.24% (1,730 examples, stop 98.96%, truncated 1.04%), GSM8K 96.66% (stop 100%).",
  },
  {
    match: { hw: "dgx-spark", variant: "default", quant: "fp4", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    speed: [
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 1, num_prompts: 8 },
        ttft_ms: 2538.64, tpot_ms: 30.18, tokens_per_sec_per_gpu: 272.44 },
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 16, num_prompts: 32 },
        ttft_ms: 23622.31, tpot_ms: 111.61, tokens_per_sec_per_gpu: 1069.73 },
    ],
    accuracy: { mmmu_pro_pct: 76.24, gsm8k_pct: 96.66 },
    notes: "DGX Spark GB10, TP=1, flashinfer_mxfp4 MoE backend (SM120 CUTLASS W4A8 path), auto-selected — verified on GB10 without an explicit --moe-runner-backend flag. Serving smoke verified on the 128GB unified-memory node with positive headroom: text and image requests complete with finish_reason=stop and reasoning split. Speed: bench_serving --flush-cache, temperature 0, TTFT/TPOT are P50; tok/s = total (input + output) token throughput on one GPU. Image workload (one 720p JPEG per request, 883 vision tokens, in/out=1024/1024): conc 1 (8 prompts): TTFT 318.70 ms, TPOT 30.70 ms, 96.26 tok/s; conc 16 (32 prompts): TTFT 9476.07 ms, TPOT 82.39 ms, 510.44 tok/s. Accuracy measured on 2×B300, TP=2 (sgl-eval, single-shot, thinking on): MMMU-Pro 76.24% (1,730 examples, stop 98.96%, truncated 1.04%), GSM8K 96.66% (stop 100%).",
  },
  {
    match: { hw: "dgx-spark", variant: "default", quant: "int4", strategy: "balanced", nodes: "single" },
    sglang_version: "dev @ bf254483a1",
    speed: [
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 1, num_prompts: 8 },
        ttft_ms: 2885.34, tpot_ms: 44.18, tokens_per_sec_per_gpu: 191.87 },
      { workload: { dataset: "random", isl: 8192, osl: 1024, max_concurrency: 16, num_prompts: 32 },
        ttft_ms: 173008.14, tpot_ms: 66.22, tokens_per_sec_per_gpu: 549.63 },
    ],
    accuracy: { mmmu_pro_pct: 77.51, gsm8k_pct: 96.97 },
    notes: "DGX Spark GB10, TP=1, auto-detected compressed-tensors int4. Serving smoke verified on the 128GB unified-memory node with positive headroom: text and image requests complete with finish_reason=stop and reasoning split. Speed: bench_serving --flush-cache, temperature 0, TTFT/TPOT are P50; tok/s = total (input + output) token throughput on one GPU. Image workload (one 720p JPEG per request, 883 vision tokens, in/out=1024/1024): conc 1 (8 prompts): TTFT 1137.64 ms, TPOT 43.92 ms, 65.14 tok/s; conc 16 (32 prompts): TTFT 137419.53 ms, TPOT 60.71 ms, 214.28 tok/s. conc-16 TTFT is queue-dominated (two waves of 16; GB10 prefill runs at ~2.8k tok/s). Accuracy measured on 2×B300, TP=2 (sgl-eval, single-shot, thinking on): MMMU-Pro 77.51% (1,730 examples, stop 98.96%, truncated 1.04%), GSM8K 96.97% (stop 100%).",
  },
];
