"""Speculative-decoding benchmark utilities."""
